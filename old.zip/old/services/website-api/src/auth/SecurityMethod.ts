export enum SecurityMethod {
	BasicAuth = 'WEBSITE-BASIC',
}
