export interface IStripeIntent {
	wishCardId: string;
	userId: string;
	email: string;
	agencyName: string;
	userDonation?: number;
}
