export interface IDonationInfo {
	email: string;
	totalAmount: number;
	orderDate: string;
	itemName: string;
	childName: string;
}
