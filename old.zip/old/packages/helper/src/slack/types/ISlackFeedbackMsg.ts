export interface ISlackFeedbackMsg {
	name: string;
	email: string;
	subject: string;
	message: string;
}
