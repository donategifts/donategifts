export interface IDonationConfirmationEmail {
	email: string;
	firstName: string;
	lastName: string;
	childName: string;
	item: string;
	price: number;
	agency: string;
}
